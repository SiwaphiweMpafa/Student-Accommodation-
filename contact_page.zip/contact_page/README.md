# phpmysql
coding of php, mysql, bootstrap, jquery

# Submit HTML form To MySQL Database An Example 

## About
This project has one HTML form to submit contact inputs in MySQL database using PHP. 
This HTML form are built using Bootstrap, Jquery.
Please, visit https://www.raghwendra.com/blog/how-to-connect-html-to-database-with-mysql-using-php-example/

## Author
* Raghwendra Ojha
* Website Development Company 
* https://www.raghwendra.com/
## Technologies
* HTML
* CSS
* PHP
* 
## Database
* MySQL

## Tools
* Github https://github.com/
* Visual Studio Code https://code.visualstudio.com/

